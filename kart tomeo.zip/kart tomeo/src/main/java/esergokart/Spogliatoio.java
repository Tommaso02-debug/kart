/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esergokart;

/**
 *
 * @author tomma
 */
public class Spogliatoio 
{
    
    
    Semaforo pieno;
    
    public Spogliatoio(Semaforo pieno)
    {
        this.pieno=pieno;
    
    }
    
    
    public void CambioI()
    {
        pieno.P();
        System.out.println("Il pilota ha indossato la tuta e il casco");
        
    
    }
    
    public void CambioI2()
    {
        pieno.V();
        System.out.println("Il pilota ha indossato i suoi indumenti");
    
    
    }
    
    
    
}
